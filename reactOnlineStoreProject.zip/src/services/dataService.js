
var catalog = [
    {
        _id: "1a2b3c4d5",
        title: "Carrots",
        price: 4.50,
        stock: 50,
        image: "carrot.jpeg",
        catagory: "Vegetable"
    },
    {
        _id: "1e2f3g4h5",
        title: "Laptop",
        price: 699.99,
        stock: 20,
        image: "laptop.jpeg",
     catagory: "Eletronics"
    },
];


class DataService {

    getCatalog() {
        // do the magic to connect to server
        // and retrieve the catalog

        // return mock data
        return catalog;
    }

}

export default DataService;