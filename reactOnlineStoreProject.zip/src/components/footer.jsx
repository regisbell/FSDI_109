

const Footer = () => {
    return (
       <div className="footer">
           <h4>Something catchy, to make customer laugh</h4>
           <h5>Store name here, 2021. All rights reserved</h5>
       </div> 
    );
}

export default Footer;