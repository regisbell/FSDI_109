import './quanityPicker.css';
import React, {useState} from 'react';

const QuanityPicker = () => {

    const [quanity, setQuanity] = useState(1);

    const increment = ()=> {
        setQuanity(quanity + 1);
    }

    const decrement = () => {
        if (quanity > 1)
            setQuanity(quanity - 1);
    }

    return (
        <div className="quanityPicker">
            <button onClick={increment}> + </button>
            <label> {quanity} </label>
            <button onClick={decrement}> - </button>
        </div>
    );
}

export default QuanityPicker