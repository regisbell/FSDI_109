/* eslint-disable jsx-a11y/alt-text */
import "./product.css";
import QuanityPicker from "./quanityPicker";

const Product = () => {
  return (
    <div className="product">
      <img src="https://picsum.photos/200/300"></img>
      <h2>Product name here</h2>
      <div>
        <label className="price">Product price</label>
        <br></br>
        <label className="total">Product total</label>
      </div>
      <div>
        <QuanityPicker></QuanityPicker>
        <button className="btn-add btn-sm btn-primary">Add to Cart</button>
        <i className="fa fa-cart-plus" aria-hidden="true"></i>
      </div>
    </div>
  );
};

export default Product;
