import "./navBar.css";


const NavBar = () => {
  return (
    <div className="navbar">
      <h5>Nav menu will be here</h5>
    </div>
  );
}

export default NavBar;
